#include "platform/clock.h"
#include "platform/core.h"
#include "platform/debug_swo.h"
#include "platform/i2c.h"
#include "platform/mpu.h"
#include "platform/time.h"
#include "platform/usb.h"

#include "board/board_i2c.h"
#include "board/board_spi.h"
#include "board/board_power.h"
#include "board/board_freq.h"

#include "drivers/adf4158.h"
#include "drivers/ad4683.h"
#include "drivers/bq25883.h"

#include "printf.h"

int main(void) {
  core_enable_faults();

  if (clock_init() != CLOCK_OK) {
    while (1) {
    }
  }

  mpu_init();
  core_enable_icache();
  core_enable_dcache();
  core_enable_cycle_counter();

  debug_swo_init();
  printf("BOOT\r\n");

  if (!time_init()) {
    printf("Time initialization failed\r\n");
    while (1) {
    }
  }

  board_power_init();
  board_i2c_init();
  board_spi_init();
  board_freq_init();

  if (!usb_init()) {
      printf("USB initialization failed\r\n");
      while (1) {}
  }

  if (i2c_init(&batt_i2c_config) != I2C_STATUS_OK) {
    printf("Battery I2C initialization failed\r\n");
    while (1) {
    }
  }

  bq25883_t battery = {.i2c = &batt_i2c_config};

  uint8_t part_info = 0;
  bq25883_status_t batt_status = bq25883_check_id(&battery, &part_info);

  printf("BQ25883 ID: %0X\r\n", part_info);

  if (batt_status != BQ25883_OK) {
    printf("BQ25883 ID check failed: %0X\r\n", batt_status);
    while (1) { }
  }

  batt_status = bq25883_prepare_for_bringup(&battery);

  if (batt_status != BQ25883_OK) {
    printf("BQ25883 configuration failed: %0X\r\n", batt_status);
    while (1) { }
  }

  uint32_t start = time_ms();
  while (!time_expired(start, 1000)) {}
  bq25883_set_charge_enabled(&battery, true);
  printf("BQ25883 ready - charging enabled\r\n");

  board_rf_5v_enable(true);
  printf("5V Enabled\r\n");

  start = time_ms();
  while (!time_expired(start, 1000U)) { }

  board_rf_15v_enable(true);
  printf("15V Enabled\r\n");

  start = time_ms();
  while (!time_expired(start, 1000U)) { }

  spi_status_t adc_status = ad4683_init();

  if (adc_status != SPI_STATUS_OK) {
      printf("ADC SPI init failed: %0X\r\n", adc_status);
      while (1) { }
  }

  printf("ADC initialized\r\n");

  // Discard the first result because ADC readback
  // has one-conversion latency.
  ad4683_sample_t sample;
  adc_status = ad4683_read_sample(&sample);

  if (adc_status != SPI_STATUS_OK) {
      printf("First ADC transfer failed\r\n");
      while (1) { }
  }


  // adf4158_ramp_result_t actual;
  // if (!adf4158_program_ramp(&ramp, &actual)) {
  //   debug_swo_write("ADF4158 ramp configuration failed\r\n");
  //
  //   board_rf_15v_enable(false);
  //   board_rf_5v_enable(false);
  //
  //   while (1) {}
  // }
  // debug_swo_write("ADF4158 ramp programmed \r\n");

  // if (!adf4158_program_fixed(&fixed)) {
  //   debug_swo_write("ADF4158 fixed configuration failed\r\n");
  //
  //   board_rf_15v_enable(false);
  //   board_rf_5v_enable(false);
  //
  //   while (1) {}
  // }
  // debug_swo_write("ADF4158 fixed programmed \r\n");

  start = time_ms();
  while (1) {
    usb_task();
    if (time_expired(start, 1000U)) {
        start = time_ms();

        adc_status = ad4683_read_sample(&sample);

        if (adc_status != SPI_STATUS_OK) {
            printf("ADC error: %0X\r\n", adc_status);
            continue;
        }

        printf("A: %d, B: %d\r\n", sample.a, sample.b);

        // bq25883_print_snapshot(&battery);
    }
  }
}
